package com.lhf.springboot.echarts.pojo;

import lombok.Data;

/**
 * @ClassName: PieData
 * @Author: liuhefei
 * @Description: TODD
 * @Date: 2019/8/21 16:19
 */
@Data
public class PieData {

    private String[] types;
    private String[] datas;
    private String title;

}
